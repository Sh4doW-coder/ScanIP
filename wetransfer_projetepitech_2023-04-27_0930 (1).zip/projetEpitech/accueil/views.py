from django.shortcuts import render
from django.http import HttpResponse 

def say_hello(request):
    return render(request, 'accueil.html')

def whatctf(request):
    return render(request, 'whatsctf.html')